<footer>
    <?=$year?>
</footer>

