<?php
define(TEMPLATES_DIR,'templates/');
define(LAYOUTS_DIR, 'layouts/');